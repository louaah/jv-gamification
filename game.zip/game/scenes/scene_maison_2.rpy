label scene_maison_2:
    # play music "music_maison.mp3"

    scene maison
    show partenaire at right

    partenaire "..."

    # menu:
    #     "Choix 1":
    #         $ fascho += 1
    #         $ loi = True
    #
    #     "Choix 2":
    #         $ loi = False

    return