label scene_parlement_1:
    # play music "music_parlement.mp3"

    scene parlement

    show chef at left

    # "..."
    # chef "..."
    # pote "..."

    # menu:
    #     "Choix 1":
    #         $ fascho += 1
    #         $ loi = True
    #
    #     "Choix 2":
    #         $ loi = False

    return