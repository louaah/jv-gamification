label start:
    call scene_maison_1
    call scene_ville_1
    call scene_parlement_1
    call scene_ville_2
    call scene_maison_2
    call scene_ville_3
    return